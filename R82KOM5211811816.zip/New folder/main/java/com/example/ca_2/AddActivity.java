package com.example.ca_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {
//create objects of edittext and add button
    EditText title_input, des_input, spent_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        title_input = findViewById(R.id.title_input);
        des_input = findViewById(R.id.des_input);
        spent_input = findViewById(R.id.spent_input);
        add_button = findViewById(R.id.add_button);
        //when i click on add
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //call mydatabase helper class
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
               //call my add method
                myDB.addHome(title_input.getText().toString().trim(),
                        des_input.getText().toString().trim(),
                        Integer.valueOf(spent_input.getText().toString().trim()));
            }
        });
    }
}
