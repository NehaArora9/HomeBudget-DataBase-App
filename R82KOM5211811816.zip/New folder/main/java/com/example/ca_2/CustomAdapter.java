package com.example.ca_2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
//this class will extends our recyclerview and it implements
//the 3 methods oncreate,onbindview,getitemcount
public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    //initialize our ArrayList
  private ArrayList home_id, home_title, home_des, home_spent;
//create constructor
    CustomAdapter(Activity activity, Context context, ArrayList home_id, ArrayList home_title, ArrayList home_des,
                  ArrayList home_spent){
        //accessing this in our whole class
        this.activity = activity;
        this.context = context;
        this.home_id = home_id;
        this.home_title = home_title;
        this.home_des = home_des;
        this.home_spent = home_spent;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       //Inflating our layout
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        //get all the data from our arrays
        holder.home_id_txt.setText(String.valueOf(home_id.get(position)));
        holder.home_title_txt.setText(String.valueOf(home_title.get(position)));
        holder.home_des_txt.setText(String.valueOf(home_des.get(position)));
        holder.home_spent_txt.setText(String.valueOf(home_spent.get(position)));
        //Recyclerview onClickListener
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(home_id.get(position)));
                intent.putExtra("title", String.valueOf(home_title.get(position)));
                intent.putExtra("des", String.valueOf(home_des.get(position)));
                intent.putExtra("spent", String.valueOf(home_spent.get(position)));
                activity.startActivityForResult(intent, 1);
            }
        });


    }

    @Override
    public int getItemCount() {
        return home_id.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
//Initialize TextView Objects
        TextView home_id_txt, home_title_txt, home_des_txt, home_spent_txt;
        LinearLayout mainLayout;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            //get the id of all the textview
            home_id_txt = itemView.findViewById(R.id.home_id_txt);
            home_title_txt = itemView.findViewById(R.id.home_title_txt);
            home_des_txt = itemView.findViewById(R.id.home_des_txt);
            home_spent_txt = itemView.findViewById(R.id.home_spent_txt);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            //Animate Recyclerview
            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);
        }

    }

}

