package com.example.ca_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.Nullable;
//this class will extends SQLiteOpenHelper and it implements
//2 methods onCreate and onUpgrade
class MyDatabaseHelper extends SQLiteOpenHelper {
    //Declare all the variables
    private Context context;
    private static final String DATABASE_NAME = "HomeBudget.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "my_homebudget";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TITLE = "home_title";
    private static final String COLUMN_DES = "home_des";
    private static final String COLUMN_SPENT = "home_spent";
//Constructor for the above class
    MyDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create table for SQL Schema and in this id is autoincrement by 1
        String query = "CREATE TABLE " + TABLE_NAME +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_DES + " TEXT, " +
                COLUMN_SPENT + " INTEGER);";
        //execute our query
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        //execute this query if our table already exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        //for upgrade the table we need to call upgrade method method
        onCreate(db);
    }
//for adding our budget
    void addHome(String title, String des, int spent){
        //for write into our table
        SQLiteDatabase db = this.getWritableDatabase();
        //store our data
        ContentValues cv = new ContentValues();
//enter the value of key and data
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_DES, des);
        cv.put(COLUMN_SPENT, spent);
        //insert our data into our table
        long result = db.insert(TABLE_NAME,null, cv);
        //if our data does not exist then its shows a toast message that failed
        //otherwise if exists then it shows added successfully
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_SHORT).show();
        }
    }
// create a method for viewing our data
    Cursor readAllData(){
        //query to select all the things from the table
        String query = "SELECT * FROM " + TABLE_NAME;
        //for reading our data
        SQLiteDatabase db = this.getReadableDatabase();
//cursor will take our data from the database
        Cursor cursor = null;
        //check if our database is not empty
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
//update our data
    void updateData(String row_id, String title, String des, String spent){
        //we can write into our database
        SQLiteDatabase db = this.getWritableDatabase();
        //store all the value
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_DES, des);
        cv.put(COLUMN_SPENT, spent);
//for updation
        long result = db.update(TABLE_NAME, cv, "_id=?", new String[]{row_id});
       //if update result not exists then its shows failed otherwise updated successfully
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Updated Successfully!", Toast.LENGTH_SHORT).show();
        }

    }
//method for deleting a single row
    void deleteOneRow(String row_id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, "_id=?", new String[]{row_id});
     //if data does not exits then its shows failed to delete otherwise successfully deleted
        if(result == -1){
            Toast.makeText(context, "Failed to Delete.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Successfully Deleted.", Toast.LENGTH_SHORT).show();
        }
    }
//method for deleting all data
    void deleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        //delete data from the table
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }

}
