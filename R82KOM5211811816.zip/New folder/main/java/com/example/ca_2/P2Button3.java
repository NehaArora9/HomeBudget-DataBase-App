package com.example.ca_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class P2Button3 extends AppCompatActivity {
    // Next activity is opened with a toast message
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2_button3);
        Toast.makeText(this, "Bluetooth Button IS Clicked", Toast.LENGTH_LONG).show();
    }
}