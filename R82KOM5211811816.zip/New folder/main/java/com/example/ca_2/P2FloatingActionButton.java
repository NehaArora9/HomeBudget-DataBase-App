package com.example.ca_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class P2FloatingActionButton extends AppCompatActivity {
    //Initialize  objects of Floating Action Button
    FloatingActionButton ffab1,ffab2,ffab3,ffab4,ffab5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // fetch the id from  xml also
        setContentView(R.layout.activity_p2_floating_action_button);
        ffab1 = findViewById(R.id.ffab1id);
        ffab2 = findViewById(R.id.ffab2id);
        ffab3 = findViewById(R.id.ffab3id);
        ffab4 = findViewById(R.id.ffab4id);
        ffab5 = findViewById(R.id.ffab5id);
// button 3 clicked -> if its visibility is visible then we set all the other 4
        //button visibility ->invisible
        ffab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ffab1.getVisibility() == View.VISIBLE)
                {
                    ffab1.setVisibility(View.INVISIBLE);
                    ffab2.setVisibility(View.INVISIBLE);
                    ffab4.setVisibility(View.INVISIBLE);
                    ffab5.setVisibility(View.INVISIBLE);
                }
                //otherwise after clicking it will be visible
                else {
                    ffab1.setVisibility(View.VISIBLE);
                    ffab2.setVisibility(View.VISIBLE);
                    ffab4.setVisibility(View.VISIBLE);
                    ffab5.setVisibility(View.VISIBLE);
                }
            }
        });
        //when button 1 is clicked then it will goes into next activity
        //and a toast message is shown at the bottom and an image view is shown at the top
        ffab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(P2FloatingActionButton.this,P2Button1.class);
                startActivity(i);
            }
        });
       // when button 2 is clicked then it will goes into next activity
        //and a toast message is shown at the bottom and an image view is shown at the top
        ffab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(P2FloatingActionButton.this,P2Button2.class);
                startActivity(i);
            }
        });
        // when button 3 is clicked then it will goes into next activity
        //and a toast message is shown at the bottom and an image view is shown at the top
        ffab4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(P2FloatingActionButton.this,P2Button3.class);
                startActivity(i);
            }
        });
        // when button 4 is clicked then it will goes into next activity
        //and a toast message is shown at the bottom and an image view is shown at the top
        ffab5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(P2FloatingActionButton.this,P2Button4.class);
                startActivity(i);
            }
        });
    }
}